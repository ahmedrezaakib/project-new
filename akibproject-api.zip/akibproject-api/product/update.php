<?php
include '../connection.php';
include '../auth_check.php';
$uploadDir = '../';
$image="";
if (!empty($_FILES['files'])) {
    foreach ($_FILES['files']['tmp_name'] as $index => $tmpName) {
        $name = rand().basename(trim($_FILES['files']['name'][$index]));
        $targetPath = 'products_file/'.$name;

        if (move_uploaded_file($tmpName, $uploadDir . $targetPath)) {
			$image=", image='$targetPath'";
        }
    }
}

if($_POST){
	$sql = "update `products` set 
		name='{$_POST['name']}',
		description='{$_POST['description']}',
		price='{$_POST['price']}',
		discount='{$_POST['discount']}',
		category_id='{$_POST['category_id']}',
		colour_id='{$_POST['colour_id']}',
		brand_id='{$_POST['brand_id']}',
		is_featured='{$_POST['is_featured']}',
		is_inspired='{$_POST['is_inspired']}',
		specification='{$_POST['specification']}'
		  $image
	where id='{$_POST['id']}'";
	
	$result=$db->query($sql);
	if($result)
		echo json_encode(array("message" => "Successful updated."));
	else
		echo json_encode(array("message" => "Failed."));
	
}


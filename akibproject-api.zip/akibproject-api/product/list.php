<?php
include '../connection.php';
include '../auth_check.php';
$data = [];

$sql = "SELECT products.*,brands.name as bname, categories.name as cat_name, colours.name as col_name FROM `products` 
JOIN categories on categories.id=products.category_id
JOIN brands on brands.id=products.brand_id
left JOIN colours on colours.id=products.colour_id";
$result=$db->query($sql);
while($row = $result->fetch_object()){
	$data[]= $row;
}
echo json_encode($data); 